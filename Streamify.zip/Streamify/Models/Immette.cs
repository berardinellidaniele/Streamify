﻿namespace Streamify.Models
{
    public class Immette
    {
        public int ID_Utente { get; set; }
        public int ID_Preferenza_Genere { get; set; }
    }

}
