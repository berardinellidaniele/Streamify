﻿namespace Streamify.Models
{
    public class Preferenza_Genere
    {
        public int ID_Preferenza_Genere { get; set; }
        public string Genere { get; set; } = string.Empty;
    }

}
