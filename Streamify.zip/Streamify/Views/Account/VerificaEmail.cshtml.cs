using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Streamify.Pages.Account
{
    public class VerificaEmailModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
